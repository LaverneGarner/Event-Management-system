/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ems;
import gui.EventPlanningForm;
import javax.swing.UIManager;
import javax.swing.SwingUtilities;
/**
 *
 * @author lavyb
 */
public class EMS {
    public static void main(String[] args) {
        try {
            // Set the look and feel to the system's look and feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Launch the frmEvents window
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Create an instance of frmEvents
                EventPlanningForm eventForm = new EventPlanningForm(); // This initializes the frmEvents form
                // Make the form visible
                eventForm.setVisible(true); // Displays the form
            }
        });
    }
    
}
